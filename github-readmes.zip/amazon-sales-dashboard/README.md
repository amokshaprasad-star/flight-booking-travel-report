# Amazon Sales Dashboard

![Dashboard preview](images/dashboard.png)

## Overview
A dashboard breaking down sales and profit by category, segment and ship mode.

**Tools:** [Confirm tool, e.g. Power BI]

## Dataset
About 25.04K orders and 10.29K products. [Add source and columns]

## What I did
- [Add steps from your report]

## Key insights
- Technology leads sales at 4.74M, then Furniture (4.11M) and Office Supplies (3.79M).
- Consumers account for 6.51M (51.48%) of sales.
- Standard Class is the most used ship mode (40.86%).

## Files
- amazon_sales_dashboard.pbix
- images/dashboard.png  (screenshot)

## Author
Adigouni Moksha Prasad Goud · [LinkedIn](https://www.linkedin.com/in/adigouni-moksha-prasad-goud-957b97292) · amokshaprasad@gmail.com
