# Prime Video Content Dashboard

![Dashboard preview](images/dashboard.png)

## Overview
A dashboard profiling a streaming catalogue by type, genre, rating, country and release year.

**Tools:** [Confirm tool, e.g. Power BI]

## Dataset
9,655 titles, 25 rating categories, 519 genre combinations and 5,771 directors. [Add source]

## What I did
- [Add steps from your report]

## Key insights
- 9,655 titles from 1920 to 2021; 7.81K movies (80.82%) and 1.85K TV shows (19.18%).
- Drama is the largest genre (986 titles), then Comedy (536).
- Titles rated 13+ lead with 2.1K.
- Output rises steeply in recent years, peaking above 1,000 titles in a single year.

## Files
- prime_video_dashboard.pbix
- images/dashboard.png  (screenshot)

## Author
Adigouni Moksha Prasad Goud · [LinkedIn](https://www.linkedin.com/in/adigouni-moksha-prasad-goud-957b97292) · amokshaprasad@gmail.com
